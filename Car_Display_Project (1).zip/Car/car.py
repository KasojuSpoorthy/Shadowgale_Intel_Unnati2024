import streamlit as st
import pandas as pd
import streamlit as st
from PIL import Image
import numpy as np
import os

st.set_page_config (page_title ="Used Cars", layout="wide",page_icon="🚘")
# Title of the app
st.title("AVAILABLE CAR FOR PURCHASE")

# Define the custom CSS

st.markdown("""
<style>
    #MainMenu {visibility: hidden;}
     footer {visibility: hidden;}
     .css-hi6a2p {padding-top: 0rem;}
    /* Hide the Streamlit deploy bar */
    .css-1kyxreq.efm0s3j10 {
            display: none;
        }
    /* Hide the Streamlit header */
    header.css-1avcm0n.egzxvld0 {
            display: none;
        }
    /* Hide the Streamlit footer */
    footer.css-1lsmgbg.egzxvld1 {
            display: none;
        }
    .css-1lsmgbg.egzxvld1 {
            display: none;
        }
        /* Hide the Streamlit footer */
    .css-9s5bis.edgvbvh3 {
            display: none;
        }
    .css-18e3th9 {
            padding-top: 0rem;
        }
    .css-1d391kg {
            padding-top: 0rem;
        }
    .css-10trblm {
            padding-top: 0rem;
        }
    .main {
            background-color: rgba(119,80,242);
        }
   div[data-testid="stSidebarNav"] {
        border-radius: 0rem;
        border: 1px solid red;
        background-color: Red;
    }
</style>

<div class="bottom-line"></div>
""",unsafe_allow_html=True)

image_dir = "C:\\Users\\Sudhasree D\\image_dir"

# Get a list of all files in the directory
image_files = [f for f in os.listdir(image_dir) if f.endswith('.jpeg') or f.endswith('.jpg')]
cols = st.columns(len(image_files))

# Display each image in the Streamlit app
#for image_file in image_files:

for col,image_file in zip(cols,image_files):
    image_path = os.path.join(image_dir, image_file)
    image = Image.open(image_path)
   # st.image(image, caption=image_file, use_column_width=True)
    col.image (image,use_column_width=True)
st.sidebar.success("Quick Search")


df = pd.read_csv(r"C:\Users\Sudhasree D\OneDrive\Desktop\IntelSummerInternship-24\cardekho.csv")
st.dataframe(df)
df['selling_price'] = pd.to_numeric(df['selling_price'], errors='coerce')
# Function to load data
 
choice = st.selectbox(

   'Select the Car you want?',

    (df.name.unique())
    )

st.write('You have selected:', choice)

data_requested = df[df.name == choice] 

st.dataframe(data_requested)

# List of URLs
st.markdown(
    """
    <style>
    .big-font {
        font-size:50px !important;
        color:white;
    }
    </style>
    """, 
    unsafe_allow_html=True
)
 
st.write('<p class="big-font">Other Used Cars Links!</p>', unsafe_allow_html=True)

urls = [
    "https://www.cardekho.com",
    "https://www.mahindrafirstchoice.com/used-cars/bangalore)"
]
cols = st.columns(len(urls))
 
# Loop through the URLs and display each one in a column
for col, url in zip(cols, urls):
    col.markdown(f"[{url}]({url})")
     