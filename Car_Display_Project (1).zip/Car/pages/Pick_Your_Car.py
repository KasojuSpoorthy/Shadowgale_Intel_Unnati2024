import streamlit as st
import pandas as pd

st.set_page_config (page_title ="Best Priced Car", layout="wide",page_icon="🚘")
st.markdown("""
<style>
    #MainMenu {visibility: hidden;}
     footer {visibility: hidden;}
     .css-hi6a2p {padding-top: 0rem;}
    /* Hide the Streamlit deploy bar */
    .css-1kyxreq.efm0s3j10 {
            display: none;
        }
    /* Hide the Streamlit header */
    header.css-1avcm0n.egzxvld0 {
            display: none;
        }
    /* Hide the Streamlit footer */
    footer.css-1lsmgbg.egzxvld1 {
            display: none;
        }
    .css-1lsmgbg.egzxvld1 {
            display: none;
        }
        /* Hide the Streamlit footer */
    .css-9s5bis.edgvbvh3 {
            display: none;
        }
    .css-18e3th9 {
            padding-top: 0rem;
        }
    .css-1d391kg {
            padding-top: 0rem;
        }
    .css-10trblm {
            padding-top: 0rem;
        }
    .main {
            background-color: rgba(147, 155,155, 0.3);
        }
   div[data-testid="stSidebarNav"] {
        border-radius: 0rem;
        border: 1px solid red;
        background-color: red;
    }
</style>
<div class="bottom-line"></div>
""",unsafe_allow_html=True)

st.title("Choose your Model, We provide Best Price")

df = pd.read_csv(r"C:\Users\Sudhasree D\OneDrive\Desktop\IntelSummerInternship-24\cardekho.csv")

choice = st.selectbox(

   'Select the Car you want?',

    (df.name.unique())
)


choice1 = st.number_input("Enter the minimum price: ",min_value=0)
choice2 = st.number_input("Enter the maximum price: ",min_value=0)
choice3 = st.number_input("Required Milage: ",min_value=0.0)
st.write('You have selected:', choice)

data_requested = df[(df.selling_price >= choice1) & (df.selling_price <= choice2) & (df.mileage >= choice3)] 

st.dataframe(data_requested)