import streamlit as st
import pandas as pd
st.set_page_config (page_title ="Car Search", layout="wide",page_icon="🚘")

# Define the custom CSS

st.markdown("""
<style>
    #MainMenu {visibility: hidden;}
     footer {visibility: hidden;}
     .css-hi6a2p {padding-top: 0rem;}
    /* Hide the Streamlit deploy bar */
    .css-1kyxreq.efm0s3j10 {
            display: none;
        }
    /* Hide the Streamlit header */
    header.css-1avcm0n.egzxvld0 {
            display: none;
        }
    /* Hide the Streamlit footer */
    footer.css-1lsmgbg.egzxvld1 {
            display: none;
        }
    .css-1lsmgbg.egzxvld1 {
            display: none;
        }
        /* Hide the Streamlit footer */
    .css-9s5bis.edgvbvh3 {
            display: none;
        }
    .css-18e3th9 {
            padding-top: 0rem;
        }
    .css-1d391kg {
            padding-top: 0rem;
        }
    .css-10trblm {
            padding-top: 0rem;
        }
    .main {
            background-color: rgba(119,80,242);
        }
   div[data-testid="stSidebarNav"] {
        border-radius: 0rem;
        border: 1px solid red;
        background-color: Red;
    }
</style>

<div class="bottom-line"></div>
""",unsafe_allow_html=True)


df = pd.read_csv(r"C:\Users\Sudhasree D\OneDrive\Desktop\IntelSummerInternship-24\cardekho.csv")
#st.dataframe(df)
choice = st.selectbox(

    'Select the Car Make you are looking for',

    (df.name.unique())
    )
choice1 = st.selectbox(

    'Select the Car Make Year',

    (df.year)
    )



data_requested = df[(df.year == choice1) & (df.name == choice)] 
st.dataframe(data_requested)
mean_price = data_requested.selling_price.mean()

st.markdown(
    """
    <style>
    .big-font {
        font-size:50px !important;
    }
    </style>
    """, 
    unsafe_allow_html=True
)
 
st.write('<p class="big-font">Best Bargain Price on your choice!</p>',mean_price,unsafe_allow_html=True)